import React, { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { FaMoon, FaSun, FaBell, FaUserCircle } from "react-icons/fa";
import "./Navbar.css";

export default function Navbar() {
  const { pathname } = useLocation();
  const [darkMode, setDarkMode] = useState(false);
  const [showDropdown, setShowDropdown] = useState(false);

  const toggleTheme = () => {
    document.body.classList.toggle("dark-mode");
    setDarkMode(!darkMode);
  };

  return (
    <nav className="navbar navbar-expand-lg custom-navbar">
      <div className="container-fluid">
        <Link className="navbar-brand logo" to="/">
          🍽 <span className="highlight">FoodMenu</span>
        </Link>

        <button
          className="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarNav"
        >
          <span className="navbar-toggler-icon"></span>
        </button>

        <div className="collapse navbar-collapse" id="navbarNav">
          <ul className="navbar-nav ms-auto align-items-center gap-3">
            <li className="nav-item">
              <Link
                className={`nav-link ${pathname === "/" ? "active" : ""}`}
                to="/"
              >
                User View
              </Link>
            </li>
            <li className="nav-item">
              <Link
                className={`nav-link ${pathname === "/admin" ? "active" : ""}`}
                to="/admin"
              >
                Admin Panel
              </Link>
            </li>

            <li className="nav-item theme-toggle" onClick={toggleTheme} title="Toggle Theme">
              {darkMode ? <FaSun /> : <FaMoon />}
            </li>

            <li className="nav-item notification position-relative" title="Notifications">
              <FaBell />
              <span className="badge">3</span>
            </li>

            <li
              className="nav-item user-dropdown"
              onClick={() => setShowDropdown((prev) => !prev)}
            >
              <FaUserCircle className="user-icon" />
              {showDropdown && (
                <div className="dropdown-menu">
                  <Link className="dropdown-item" to="/">Profile</Link>
                  <Link className="dropdown-item" to="/">Settings</Link>
                  <Link className="dropdown-item" to="/">Logout</Link>
                </div>
              )}
            </li>
          </ul>
        </div>
      </div>
    </nav>
  );
}
// Note: Ensure you have the necessary CSS for the dark mode and dropdown styles in Navbar.css
// Also, make sure to include the FontAwesome icons in your project for the icons to render 
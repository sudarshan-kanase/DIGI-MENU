import React from "react";
import "./Footer.css";

export default function Footer() {
  return (
    <footer className="custom-footer">
      <div className="footer-content">
        <div className="footer-left">
          <h4>🍽️ Foodie Menu</h4>
          <p>&copy; {new Date().getFullYear()} All rights reserved.</p>
        </div>
        <div className="footer-links">
          <a href="#about">About</a>
          <a href="#menu">Menu</a>
          <a href="#contact">Contact</a>
        </div>
        <div className="footer-icons">
          <a href="https://facebook.com" target="_blank" rel="noreferrer">
            <i className="fab fa-facebook-f"></i>
          </a>
          <a href="https://twitter.com" target="_blank" rel="noreferrer">
            <i className="fab fa-twitter"></i>
          </a>
          <a href="https://instagram.com" target="_blank" rel="noreferrer">
            <i className="fab fa-instagram"></i>
          </a>
        </div>
      </div>
    </footer>
  );
}
// This Footer component provides a consistent footer across the application.
// It includes links to the about, menu, and contact sections, as well as social media  